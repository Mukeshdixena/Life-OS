/* APP — root */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "simulatedHour": 10,
  "simulatedMinute": 18,
  "showCheckin": false
}/*EDITMODE-END*/;

const App = () => {
  const { useState, useEffect, useMemo } = React;
  const [tweaks, setTweak] = window.useTweaks
    ? window.useTweaks(TWEAK_DEFAULTS)
    : (() => { const [s, set] = useState(TWEAK_DEFAULTS); return [s, (k, v) => typeof k === 'object' ? set(o => ({...o, ...k})) : set(o => ({...o, [k]: v}))]; })();

  const [active, setActive] = useState('today');
  const [checkinOpen, setCheckinOpen] = useState(false);
  const [tick, setTick] = useState(0);

  // Apply theme
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', tweaks.theme);
  }, [tweaks.theme]);

  // 1Hz tick for the countdown
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const now = (tweaks.simulatedHour * 60) + tweaks.simulatedMinute + (tick / 60);
  const currentBlock = window.SCHEDULE.find(b => now >= b.start && now < b.end);
  const nextBlocks = window.SCHEDULE.filter(b => b.start > now).slice(0, 3);

  // Sync checkin from tweak
  useEffect(() => { if (tweaks.showCheckin) setCheckinOpen(true); }, [tweaks.showCheckin]);

  const setTheme = (v) => setTweak('theme', v);

  const renderScreen = () => {
    switch (active) {
      case 'today':
        return <window.ScreenToday
          now={now}
          currentBlock={currentBlock}
          nextBlocks={nextBlocks}
          checkinOpen={checkinOpen}
          onComplete={() => setCheckinOpen(true)}
          onCloseCheckin={() => { setCheckinOpen(false); setTweak('showCheckin', false); }}
          onCheckinChoose={() => { setCheckinOpen(false); setTweak('showCheckin', false); }}
        />;
      case 'plan':
        return <window.ScreenPlan onDone={() => setActive('today')} />;
      case 'review':
        return <ReviewStub />;
      case 'dashboard':
        return <window.ScreenDashboard />;
      case 'history':
        return <window.ScreenHistory />;
      case 'settings':
        return <window.ScreenSettings theme={tweaks.theme} onTheme={setTheme} />;
      default:
        return null;
    }
  };

  const crumbs = {
    today: 'HOME / TODAY',
    plan: 'HOME / PLAN',
    review: 'HOME / REVIEW',
    dashboard: 'HOME / DASHBOARD',
    history: 'HOME / HISTORY',
    settings: 'HOME / SETTINGS',
  }[active];

  const clockNow = window.fmtTime(Math.floor(now)).toUpperCase();

  return (
    <div className="app-shell" data-screen-label={active}>
      <window.Sidebar active={active} onNav={setActive} theme={tweaks.theme} onTheme={setTheme} />
      <div className="main-area">
        <div className="top-bar">
          <div className="crumbs">{crumbs}</div>
          <div className="clock">{clockNow} · TUE APR 28</div>
        </div>
        <div className="main-scroll" key={active}>
          {renderScreen()}
        </div>
      </div>

      {window.TweaksPanel && (
        <window.TweaksPanel>
          <window.TweakSection label="Theme" />
          <window.TweakRadio
            label="Mode"
            value={tweaks.theme}
            onChange={v => setTweak('theme', v)}
            options={['light', 'dark']}
          />
          <window.TweakSection label="Simulated time" />
          <window.TweakSlider label="Hour" min={6} max={23} step={1}
            value={tweaks.simulatedHour}
            onChange={v => setTweak('simulatedHour', v)} />
          <window.TweakSlider label="Minute" min={0} max={59} step={1}
            value={tweaks.simulatedMinute}
            onChange={v => setTweak('simulatedMinute', v)} />
          <window.TweakSection label="States" />
          <window.TweakToggle
            label="Show check-in"
            value={tweaks.showCheckin}
            onChange={v => setTweak('showCheckin', v)} />
        </window.TweaksPanel>
      )}
    </div>
  );
};

const ReviewStub = () => (
  <div className="page-fade">
    <div className="dash-head">
      <div>
        <div className="label-eyebrow" style={{ marginBottom: 4 }}>End of day</div>
        <h1>Review</h1>
      </div>
    </div>
    <div className="card card-tall" style={{ maxWidth: 720 }}>
      <div className="label-eyebrow">Tonight's reflection</div>
      <h2 style={{ fontFamily: 'DM Serif Display', fontSize: 30, margin: '6px 0 14px' }}>How was today?</h2>
      <p style={{ color: 'var(--text-2)', lineHeight: 1.6, fontSize: 14 }}>
        Reflection lives here at end-of-day — completion confirmation per block, a few prompts, mood/energy ratings, and tomorrow's anchor. For now, see <b>Today</b> for live tracking and <b>Dashboard</b> for the trends.
      </p>
    </div>
  </div>
);

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
