/* SETTINGS */

const ScreenSettings = ({ theme, onTheme }) => {
  const [tab, setTab] = React.useState('theme');
  const tabs = [
    { id: 'profile', label: 'Profile' },
    { id: 'areas', label: 'Life Areas' },
    { id: 'nn', label: 'Non-Negotiables' },
    { id: 'habits', label: 'Habits' },
    { id: 'prefs', label: 'Preferences' },
    { id: 'theme', label: 'Theme' },
    { id: 'data', label: 'Data' },
  ];

  return (
    <div className="page-fade">
      <div className="dash-head">
        <div>
          <div className="label-eyebrow" style={{ marginBottom: 4 }}>Configuration</div>
          <h1>Settings</h1>
        </div>
      </div>

      <div className="settings-grid">
        <div className="set-nav">
          {tabs.map(t => (
            <button key={t.id} className={tab === t.id ? 'active' : ''} onClick={() => setTab(t.id)}>{t.label}</button>
          ))}
        </div>

        <div>
          {tab === 'theme' && (
            <div className="card card-tall">
              <div className="label-eyebrow">Appearance</div>
              <h2 style={{ fontFamily: 'DM Serif Display', fontSize: 28, margin: '4px 0 18px', letterSpacing: '-0.01em' }}>Pick your atmosphere</h2>
              <div className="theme-preview-grid">
                <div className={`theme-preview light ${theme === 'light' ? 'sel' : ''}`} onClick={() => onTheme('light')}>
                  <div className="label">Paper · Light</div>
                  <div className="mock">
                    <div className="tp-line lg"></div>
                    <div className="tp-line md"></div>
                    <div className="tp-line sm"></div>
                    <div className="tp-line md"></div>
                    <div className="tp-line lg"></div>
                  </div>
                </div>
                <div className={`theme-preview dark ${theme === 'dark' ? 'sel' : ''}`} onClick={() => onTheme('dark')}>
                  <div className="label">Quiet night · Dark</div>
                  <div className="mock">
                    <div className="tp-line lg"></div>
                    <div className="tp-line md"></div>
                    <div className="tp-line sm"></div>
                    <div className="tp-line md"></div>
                    <div className="tp-line lg"></div>
                  </div>
                </div>
              </div>
              <p style={{ fontSize: 13, color: 'var(--text-2)', marginTop: 18, lineHeight: 1.55 }}>
                Your theme stays where you set it — Life OS won't follow your system. Some moments call for paper. Others, for the quiet of night.
              </p>
            </div>
          )}

          {tab === 'areas' && (
            <div>
              <div className="label-eyebrow" style={{ marginBottom: 12 }}>Your life areas</div>
              {Object.values(window.CATEGORIES).map(c => (
                <div key={c.id} className="area-row" style={{ '--cat': c.hex }}>
                  <span className="area-sw"></span>
                  <span className="name">{c.name}</span>
                  <span className="meta">~{Math.floor(Math.random()*12)+2}h/wk</span>
                  <span className="toggle-mini on"></span>
                </div>
              ))}
              <button className="btn btn-outline" style={{ marginTop: 8 }}>
                <window.Icons.Plus size={14} /> Add area
              </button>
            </div>
          )}

          {tab === 'nn' && (
            <div>
              <div className="label-eyebrow" style={{ marginBottom: 12 }}>Non-negotiables — your daily floor</div>
              {window.NON_NEGOTIABLES.map((n, i) => (
                <div key={i} className="area-row" style={{ '--cat': '#3B82F6' }}>
                  <window.Icons.Drag size={16} />
                  <span className="name">{n.name}</span>
                  <span className="meta">{n.dur}</span>
                  <span className={`toggle-mini ${n.on ? 'on' : ''}`}></span>
                </div>
              ))}
            </div>
          )}

          {(tab === 'profile' || tab === 'habits' || tab === 'prefs' || tab === 'data') && (
            <div className="card card-tall">
              <div className="label-eyebrow">{tabs.find(t=>t.id===tab).label}</div>
              <h2 style={{ fontFamily: 'DM Serif Display', fontSize: 26, margin: '6px 0 12px', letterSpacing: '-0.01em' }}>Coming together</h2>
              <p style={{ color: 'var(--text-2)', fontSize: 14, lineHeight: 1.6 }}>
                This panel hosts the {tabs.find(t=>t.id===tab).label.toLowerCase()} configuration. Use the Theme and Life Areas panels for now — those are wired to live state.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

window.ScreenSettings = ScreenSettings;
