/* HISTORY */

const ScreenHistory = () => {
  const [selected, setSelected] = React.useState(28); // April 28
  const I = window.Icons;
  const days = [];
  // April 2026 — starts on Wednesday (day 3 of week, M=0)
  const monthStart = 2; // 0=M
  for (let i = 0; i < monthStart; i++) days.push({ blank: true });
  for (let d = 1; d <= 30; d++) days.push({
    n: d,
    completion: Math.max(0.2, Math.min(1, 0.5 + Math.sin(d) * 0.3 + (d % 5 === 0 ? 0.2 : 0))),
    cats: ['work', 'health', 'learning', 'personal', 'relationships'][d % 5],
    isToday: d === 28,
    isFuture: d > 28,
  });

  const sel = days.find(d => !d.blank && d.n === selected);
  const dateLabel = sel ? new Date(2026, 3, sel.n).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' }) : '';

  return (
    <div className="page-fade">
      <div className="dash-head">
        <div>
          <div className="label-eyebrow" style={{ marginBottom: 4 }}>Past days</div>
          <h1>History</h1>
        </div>
      </div>

      <div className="hist-grid">
        <div>
          <div className="cal-head">
            <h2>April 2026</h2>
            <div className="cal-nav">
              <button><I.ChevronLeft size={16} /></button>
              <button><I.ChevronRight size={16} /></button>
            </div>
          </div>

          <div className="cal-grid">
            {['M','T','W','T','F','S','S'].map((d, i) => (
              <div key={i} className="cal-day-h">{d}</div>
            ))}
            {days.map((d, i) => {
              if (d.blank) return <div key={i}></div>;
              const cls = `cal-cell ${d.isToday ? 'today' : ''} ${d.isFuture ? 'future' : ''} ${selected === d.n ? 'selected' : ''}`;
              const pct = Math.round(d.completion * 100);
              const ringColor = pct >= 80 ? '#22C55E' : pct >= 50 ? 'var(--accent)' : '#E5A93A';
              return (
                <div key={i} className={cls} onClick={() => !d.isFuture && setSelected(d.n)}>
                  <div className="cal-row1">
                    <span className="num">{d.n}</span>
                    {!d.isFuture && <window.Ring pct={pct} size={20} stroke={2.5} color={ringColor} />}
                  </div>
                  {!d.isFuture && (
                    <div className="cal-dots">
                      {['work','health','personal'].map((c, j) => (
                        <span key={j} style={{ background: window.CATEGORIES[c].hex }}></span>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="day-detail">
          <div className="label-eyebrow">{sel?.isToday ? 'In progress' : 'Logged'}</div>
          <h2>{dateLabel}</h2>

          <div className="dd-stats">
            <div className="dd-stat"><div className="lbl">Planned</div><div className="val">8h 55m</div></div>
            <div className="dd-stat"><div className="lbl">Actual</div><div className="val">7h 30m</div></div>
            <div className="dd-stat"><div className="lbl">Completion</div><div className="val">84%</div></div>
            <div className="dd-stat"><div className="lbl">Top area</div><div className="val">Deep Work</div></div>
          </div>

          <div className="label-eyebrow" style={{ marginBottom: 8 }}>Mini timeline</div>
          <div className="mini-tl">
            {window.SCHEDULE.slice(0, 10).map(b => {
              const c = window.CATEGORIES[b.cat];
              return (
                <div key={b.id} className="mini-row" style={{ '--cat': c.hex }}>
                  <span className="t">{window.fmtTime(b.start)}</span>
                  <span className="nm">{b.title}</span>
                  <window.Icons.Check size={12} stroke={3} color="var(--cat-health)" />
                </div>
              );
            })}
          </div>

          <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
            <div className="gauge">
              <span className="lbl">Mood</span>
              <svg viewBox="0 0 60 30">
                <path d="M5 25 A 25 25 0 0 1 55 25" fill="none" stroke="var(--border)" strokeWidth="3" />
                <path d="M5 25 A 25 25 0 0 1 45 8" fill="none" stroke="#F97316" strokeWidth="3" strokeLinecap="round" />
                <circle cx="45" cy="8" r="3" fill="#F97316" />
              </svg>
            </div>
            <div className="gauge">
              <span className="lbl">Energy</span>
              <svg viewBox="0 0 60 30">
                <path d="M5 25 A 25 25 0 0 1 55 25" fill="none" stroke="var(--border)" strokeWidth="3" />
                <path d="M5 25 A 25 25 0 0 1 50 12" fill="none" stroke="#3B82F6" strokeWidth="3" strokeLinecap="round" />
                <circle cx="50" cy="12" r="3" fill="#3B82F6" />
              </svg>
            </div>
          </div>

          <div style={{ marginTop: 18 }}>
            <div className="label-eyebrow" style={{ marginBottom: 8 }}>Check-in notes</div>
            <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.55, padding: '10px 12px', background: 'var(--bg-3)', borderRadius: 8 }}>
              "Felt sharp through morning deep work. Lunch with Maya gave me a second wind. Almost skipped the afternoon walk — glad I didn't."
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

window.ScreenHistory = ScreenHistory;
