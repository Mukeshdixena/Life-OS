/* TODAY SCREEN */

const PX_PER_HOUR = 76;
const TL_START = 6 * 60;   // 6:00am
const TL_END = 23 * 60;    // 11pm

const yFor = (min) => ((min - TL_START) / 60) * PX_PER_HOUR;

const StatusIcon = ({ kind, color }) => {
  const I = window.Icons;
  if (kind === 'done') return <span className="tl-status done"><I.Check size={11} stroke={3} /></span>;
  if (kind === 'active') return <span className="tl-status active-s"><I.Play size={9} stroke={2.5} /></span>;
  return <span className="tl-status pending"><I.Dash size={11} stroke={3} /></span>;
};

const TimelineBlock = ({ block, status, idx }) => {
  const cat = window.CATEGORIES[block.cat];
  const top = yFor(block.start);
  const height = Math.max(40, ((block.end - block.start) / 60) * PX_PER_HOUR - 4);
  const dur = block.end - block.start;
  const cls = `tl-block ${status}`;
  return (
    <div className={cls} style={{
      top: `${top}px`, height: `${height}px`,
      '--cat': cat.hex, '--d': `${idx * 30}ms`,
    }}>
      <div className="row1">
        <div className="title">{block.title}</div>
        <StatusIcon kind={status === 'past' ? 'done' : status === 'active' ? 'active' : 'pending'} />
      </div>
      <div className="meta">
        <window.Pill cat={block.cat} />
        <span className="duration">{window.fmtTime(block.start)} · {window.durLabel(dur)}</span>
      </div>
    </div>
  );
};

const Timeline = ({ now }) => {
  const ticks = [];
  for (let m = TL_START; m <= TL_END; m += 30) {
    const isHour = m % 60 === 0;
    ticks.push(
      <div key={m} className={`timeline-tick ${isHour ? 'hour' : ''}`} style={{ top: `${yFor(m)}px` }}>
        {isHour ? window.fmtTime(m) : ''}
      </div>
    );
  }

  // figure out status for each block
  const items = window.SCHEDULE.filter(b => b.start < TL_END).map((b, i) => {
    let status = 'future';
    if (now >= b.end) status = 'past';
    else if (now >= b.start) status = 'active';
    return { b, status, i };
  });

  const totalHeight = ((TL_END - TL_START) / 60) * PX_PER_HOUR;

  return (
    <div className="timeline" style={{ minHeight: `${totalHeight + 24}px` }}>
      <div className="timeline-axis" style={{ height: `${totalHeight}px` }}>
        {ticks}
      </div>
      <div className="timeline-track" style={{ height: `${totalHeight}px` }}>
        {items.map(({ b, status, i }) => (
          <TimelineBlock key={b.id} block={b} status={status} idx={i} />
        ))}
        {now >= TL_START && now <= TL_END && (
          <div className="now-line" style={{ top: `${yFor(now)}px` }}>
            <span className="label">{window.fmtTime(Math.floor(now))}</span>
          </div>
        )}
      </div>
    </div>
  );
};

const CountdownRing = ({ remaining, total, color }) => {
  const size = 220, stroke = 10;
  const r = (size - stroke) / 2 - 8;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(1, remaining / total));
  // Tick marks
  const ticks = [];
  for (let i = 0; i < 60; i++) {
    const angle = (i / 60) * Math.PI * 2;
    const isMajor = i % 5 === 0;
    const r1 = r - 12, r2 = isMajor ? r - 4 : r - 8;
    const cx = size/2 + Math.cos(angle) * r1;
    const cy = size/2 + Math.sin(angle) * r1;
    const cx2 = size/2 + Math.cos(angle) * r2;
    const cy2 = size/2 + Math.sin(angle) * r2;
    ticks.push(<line key={i} x1={cx} y1={cy} x2={cx2} y2={cy2}
      className="ring-tick" strokeWidth={isMajor ? 1.5 : 1} />);
  }
  return (
    <svg viewBox={`0 0 ${size} ${size}`}>
      {ticks.map((t, i) => React.cloneElement(t, { key: i }))}
      <circle cx={size/2} cy={size/2} r={r} fill="none" strokeWidth={stroke} className="ring-bg" />
      <circle cx={size/2} cy={size/2} r={r} fill="none" strokeWidth={stroke}
        className="ring-fg"
        stroke={color}
        strokeDasharray={c}
        strokeDashoffset={c * (1 - pct)}
        strokeLinecap="round" />
    </svg>
  );
};

const NowPanel = ({ now, currentBlock, nextBlocks, onComplete }) => {
  if (!currentBlock) {
    return (
      <div className="now-panel">
        <div className="now-card" style={{ '--cat': '#6B7280' }}>
          <div className="header">
            <span className="now-eyebrow">Now</span>
            <h2>Between blocks</h2>
            <div className="muted" style={{ fontSize: 13 }}>No active block — take a breath.</div>
          </div>
        </div>
      </div>
    );
  }

  const cat = window.CATEGORIES[currentBlock.cat];
  const total = (currentBlock.end - currentBlock.start) * 60;  // seconds
  const elapsed = (now - currentBlock.start) * 60;
  const remaining = Math.max(0, total - elapsed);
  const ratio = remaining / total;
  let ringColor = '#22C55E';
  if (ratio < 0.5) ringColor = '#E5A93A';
  if (ratio < 0.2) ringColor = '#E0524A';

  const hh = Math.floor(remaining / 3600);
  const mm = Math.floor((remaining % 3600) / 60);
  const ss = Math.floor(remaining % 60);
  const tt = hh > 0
    ? `${hh}:${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}`
    : `${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}`;

  const elapsedPct = (elapsed / total) * 100;

  return (
    <div className="now-panel">
      <div className="now-card" style={{ '--cat': cat.hex }}>
        <div className="header">
          <span className="now-eyebrow">Now</span>
          <h2>{currentBlock.title}</h2>
          <div style={{ marginTop: 4 }}>
            <window.Pill cat={currentBlock.cat} />
          </div>
        </div>

        <div className="timer-wrap">
          <CountdownRing remaining={remaining} total={total} color={ringColor} />
          <div className="timer-center">
            <div>
              <div className="timer-time" style={{ color: ringColor }}>{tt}</div>
              <div className="timer-sub">REMAINING</div>
            </div>
          </div>
        </div>

        <div className="thin-progress">
          <div className="fill" style={{ width: `${Math.min(100, elapsedPct)}%`, background: ringColor }}></div>
        </div>

        <div className="now-actions">
          <button className="btn btn-outline" onClick={onComplete}>Complete Early</button>
          <button className="btn btn-outline">Need More Time</button>
        </div>
      </div>

      <div className="up-next">
        <div className="head">
          <window.Eyebrow>Coming Up</window.Eyebrow>
          <span style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'JetBrains Mono, monospace' }}>NEXT 3</span>
        </div>
        {nextBlocks.length === 0 && <div className="muted" style={{ fontSize: 13, padding: '10px 0' }}>You're done for the day. Rest well.</div>}
        {nextBlocks.map(b => {
          const c = window.CATEGORIES[b.cat];
          return (
            <div key={b.id} className="row" style={{ '--cat': c.hex }}>
              <span className="dot"></span>
              <div className="name">{b.title}</div>
              <div className="when">{window.fmtTime(b.start)}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const CheckinModal = ({ block, onClose, onChoose }) => {
  if (!block) return null;
  const I = window.Icons;
  const opts = [
    { id: 'done', icon: '✅', label: 'Done — move to next', desc: 'Mark complete and start the next block', tone: '#22C55E' },
    { id: 'more', icon: '⏳', label: 'Need more time', desc: 'Extend by 15, 30, 45 minutes — or custom', tone: '#E5A93A' },
    { id: 'else', icon: '🔀', label: 'I did something else', desc: 'Log what you actually worked on', tone: '#3B82F6' },
    { id: 'skip', icon: '⏭', label: 'Skip this block', desc: 'Move on without logging time', tone: '#9E9890' },
  ];
  return (
    <div className="modal-back" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h3>Block complete</h3>
        <div className="sub">{block.title} · {window.durLabel(block.end - block.start)}</div>
        {opts.map(o => (
          <button key={o.id} className="checkin-opt" style={{ '--tone': o.tone }} onClick={() => onChoose(o.id)}>
            <span className="ic" style={{ fontSize: 20 }}>{o.icon}</span>
            <div>
              <div className="lbl">{o.label}</div>
              <div className="desc">{o.desc}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

const ScreenToday = ({ now, currentBlock, nextBlocks, checkinOpen, onComplete, onCloseCheckin, onCheckinChoose }) => {
  const today = new Date(2026, 3, 28); // Tuesday, April 28
  const dateStr = today.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

  const scrollRef = React.useRef();
  React.useEffect(() => {
    if (!scrollRef.current) return;
    const target = yFor(now) - 200;
    scrollRef.current.scrollTo({ top: target, behavior: 'smooth' });
  }, []);

  return (
    <div className="page-fade" ref={scrollRef}>
      <div className="today-head">
        <div className="eyebrow"><window.Eyebrow>Tuesday · Day 87 of 365</window.Eyebrow></div>
        <h1>Today</h1>
        <div className="sub">{dateStr} — 14 blocks planned · 8h 55m of intentional time</div>
      </div>

      <div className="today-grid">
        <div>
          <Timeline now={now} />
        </div>
        <NowPanel now={now} currentBlock={currentBlock} nextBlocks={nextBlocks} onComplete={onComplete} />
      </div>

      {checkinOpen && (
        <CheckinModal block={currentBlock} onClose={onCloseCheckin} onChoose={onCheckinChoose} />
      )}
    </div>
  );
};

window.ScreenToday = ScreenToday;
