/* Data: schedule, dashboard, history */

const CATEGORIES = {
  work: { id: 'work', name: 'Deep Work', color: 'var(--cat-work)', hex: '#3B82F6' },
  health: { id: 'health', name: 'Health', color: 'var(--cat-health)', hex: '#22C55E' },
  learning: { id: 'learning', name: 'Learning', color: 'var(--cat-learning)', hex: '#A855F7' },
  relationships: { id: 'relationships', name: 'People', color: 'var(--cat-relationships)', hex: '#F97316' },
  admin: { id: 'admin', name: 'Admin', color: 'var(--cat-admin)', hex: '#6B7280' },
  personal: { id: 'personal', name: 'Personal', color: 'var(--cat-personal)', hex: '#EC4899' },
  sleep: { id: 'sleep', name: 'Rest', color: 'var(--cat-sleep)', hex: '#1E3A5F' },
};

// Today's schedule. Time in minutes from midnight.
const SCHEDULE = [
  { id: 1, title: "Morning routine + Coffee", cat: 'personal', start: 6 * 60 + 30, end: 7 * 60 + 15 },
  { id: 2, title: "Strength training", cat: 'health', start: 7 * 60 + 15, end: 8 * 60 + 15 },
  { id: 3, title: "Shower & breakfast", cat: 'personal', start: 8 * 60 + 15, end: 8 * 60 + 50 },
  { id: 4, title: "Inbox & async standup", cat: 'admin', start: 9 * 60, end: 9 * 60 + 45 },
  { id: 5, title: "Deep work — Q3 proposal", cat: 'work', start: 9 * 60 + 45, end: 11 * 60 + 30 },
  { id: 6, title: "Walk + podcast", cat: 'learning', start: 11 * 60 + 30, end: 12 * 60 },
  { id: 7, title: "Lunch with Maya", cat: 'relationships', start: 12 * 60, end: 13 * 60 + 15 },
  { id: 8, title: "Design review", cat: 'work', start: 13 * 60 + 30, end: 14 * 60 + 30 },
  { id: 9, title: "Deep work — Implementation", cat: 'work', start: 14 * 60 + 45, end: 16 * 60 + 30 },
  { id: 10, title: "Reading — 'Antifragile'", cat: 'learning', start: 16 * 60 + 45, end: 17 * 60 + 30 },
  { id: 11, title: "Call mom", cat: 'relationships', start: 17 * 60 + 30, end: 18 * 60 },
  { id: 12, title: "Dinner & wind-down", cat: 'personal', start: 18 * 60 + 30, end: 19 * 60 + 30 },
  { id: 13, title: "Journal + plan tomorrow", cat: 'admin', start: 21 * 60, end: 21 * 60 + 30 },
  { id: 14, title: "Sleep", cat: 'sleep', start: 22 * 60 + 30, end: 30 * 60 },
];

// Dashboard data
const PLANNED_VS_ACTUAL = [
  { cat: 'work', planned: 22, actual: 19.5 },
  { cat: 'health', planned: 7, actual: 8 },
  { cat: 'learning', planned: 6, actual: 4.5 },
  { cat: 'relationships', planned: 5, actual: 6 },
  { cat: 'personal', planned: 8, actual: 7 },
  { cat: 'admin', planned: 4, actual: 5 },
];

const COMPLETION_TREND = [62, 68, 71, 65, 78, 82, 76, 88, 84, 79, 86, 91, 78];
const MOOD_TREND = [3, 3.5, 4, 3, 4, 4.5, 4, 5, 4.5, 4, 4.5, 5, 4];
const ENERGY_TREND = [2.5, 3, 3.5, 3, 4, 4, 3.5, 4.5, 4, 3.5, 4, 4.5, 4];

// 364 days, deterministic-ish
const HEATMAP = (() => {
  const out = [];
  for (let i = 0; i < 364; i++) {
    const seed = Math.sin(i * 12.9898) * 43758.5453;
    const v = seed - Math.floor(seed);
    let lvl = Math.max(0, Math.min(1, v * 0.6 + (i > 200 ? 0.3 : 0.1)));
    if (i % 7 === 0 || i % 7 === 6) lvl *= 0.6;
    out.push(Math.round(lvl * 100) / 100);
  }
  return out;
})();

const HABITS = [
  { name: 'Morning workout', pct: 86 },
  { name: 'Read 30 min', pct: 72 },
  { name: 'Journal', pct: 64 },
  { name: 'No phone after 10pm', pct: 58 },
  { name: 'Meditate', pct: 92 },
];

const ROI = [
  { kind: 'Earned', hours: 18, color: '#3B82F6' },
  { kind: 'Growth', hours: 14, color: '#22C55E' },
  { kind: 'Maintenance', hours: 9, color: '#9E9890' },
  { kind: 'Low value', hours: 6, color: '#E0524A' },
];

const NON_NEGOTIABLES = [
  { name: 'Strength training', dur: '60m', icon: 'health', on: true },
  { name: 'Read', dur: '30m', icon: 'book', on: true },
  { name: 'Journal', dur: '10m', icon: 'pen', on: true },
  { name: '8h sleep window', dur: '8h', icon: 'moon', on: true },
  { name: 'Connect with someone', dur: '20m', icon: 'people', on: false },
];

const fmtTime = (min) => {
  const h = Math.floor(min / 60) % 24;
  const m = min % 60;
  const ap = h >= 12 ? 'pm' : 'am';
  const h12 = ((h + 11) % 12) + 1;
  return `${h12}:${String(m).padStart(2, '0')} ${ap}`;
};
const durLabel = (mins) => {
  const h = Math.floor(mins / 60), m = mins % 60;
  if (h && m) return `${h}h ${m}m`;
  if (h) return `${h}h`;
  return `${m}m`;
};

Object.assign(window, { CATEGORIES, SCHEDULE, PLANNED_VS_ACTUAL, COMPLETION_TREND, MOOD_TREND, ENERGY_TREND, HEATMAP, HABITS, ROI, NON_NEGOTIABLES, fmtTime, durLabel });
