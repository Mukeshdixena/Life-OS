/* PLAN — 3-step wizard */

const StepIndicator = ({ step }) => (
  <div className="steps">
    {[1, 2, 3].map(n => (
      <React.Fragment key={n}>
        <div className={`step ${step === n ? 'active' : ''} ${step > n ? 'done' : ''}`}>
          <span className="num">{step > n ? '✓' : n}</span>
          <span>{n === 1 ? 'Check in' : n === 2 ? 'Set intent' : 'Review'}</span>
        </div>
        {n < 3 && <div className="bar" style={{ width: 40, height: 1, background: 'var(--border)' }}></div>}
      </React.Fragment>
    ))}
  </div>
);

const Step1 = ({ values, set, onNext }) => {
  const energy = [
    { v: 1, em: '😴', l: 'Drained' },
    { v: 2, em: '😐', l: 'Low' },
    { v: 3, em: '🙂', l: 'Okay' },
    { v: 4, em: '⚡', l: 'Energized' },
    { v: 5, em: '🚀', l: 'Fired up' },
  ];
  const moods = ['Focused', 'Scattered', 'Stressed', 'Motivated'];
  return (
    <>
      <h1 className="plan-h">Good morning, Sasha</h1>
      <p className="plan-sub">Take 30 seconds to check in with yourself before we plan.</p>

      <div className="q-row">
        <label>How's your energy?</label>
        <div className="energy-row">
          {energy.map(e => (
            <button key={e.v} className={`energy-btn ${values.energy === e.v ? 'sel' : ''}`} onClick={() => set('energy', e.v)}>
              <span className="em">{e.em}</span>
              <span className="lb">{e.l}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="q-row">
        <label>Your headspace?</label>
        <div className="mood-row">
          {moods.map(m => (
            <button key={m} className={`mood-pill ${values.mood === m ? 'sel' : ''}`} onClick={() => set('mood', m)}>{m}</button>
          ))}
        </div>
      </div>

      <div className="q-row">
        <label>Sleep quality?</label>
        <div className="stars">
          {[1,2,3,4,5].map(n => (
            <button key={n} className={`star-btn ${values.sleep >= n ? 'lit' : ''}`} onClick={() => set('sleep', n)}>
              <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2l2.9 6.9 7.4.6-5.6 4.9 1.7 7.3-6.4-3.9-6.4 3.9 1.7-7.3-5.6-4.9 7.4-.6z"/>
              </svg>
            </button>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 24 }}>
        <button className="btn btn-primary btn-large" onClick={onNext}>
          Continue <window.Icons.ArrowRight size={16} />
        </button>
      </div>
    </>
  );
};

const Step2 = ({ values, set, onBack, onNext, loading }) => {
  const I = window.Icons;
  const chips = ['Gym', 'Deep work', 'Reading', 'Meditation', 'Walk', 'Call mom'];
  return (
    <>
      <h1 className="plan-h">What's on your plate?</h1>
      <p className="plan-sub">Brain-dump everything. The system will arrange it into blocks.</p>

      <div className="intent-card">
        <window.Eyebrow>Today's intent</window.Eyebrow>
        <textarea className="textarea" style={{ marginTop: 10 }}
          placeholder="e.g. Morning gym, office meetings till 2pm, finish the Q3 proposal, call mom, some reading before bed…"
          value={values.intent}
          onChange={e => set('intent', e.target.value)} />
        <div className="chip-row">
          {chips.map(c => (
            <button key={c} className="chip" onClick={() => set('intent', (values.intent ? values.intent + ', ' : '') + c.toLowerCase())}>+ {c}</button>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 24 }}>
        <button className="btn btn-ghost" onClick={onBack}>← Back</button>
        <button className="btn btn-primary btn-large" onClick={onNext}>
          <I.Sparkles size={16} /> Generate my day
        </button>
      </div>

      {loading && (
        <div style={{ marginTop: 28 }}>
          <window.Eyebrow>Generating</window.Eyebrow>
          <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[68, 92, 56, 110, 80, 64].map((h, i) => (
              <div key={i} className="skel" style={{ height: h }}></div>
            ))}
          </div>
        </div>
      )}
    </>
  );
};

const Step3 = ({ onBack, onConfirm }) => {
  const cats = window.PLANNED_VS_ACTUAL.slice(0, 5);
  const total = cats.reduce((s, c) => s + c.planned, 0);
  return (
    <>
      <h1 className="plan-h">Review your day</h1>
      <p className="plan-sub">Drag to reorder. Edit titles. Confirm when ready.</p>

      <div className="review-grid">
        <div className="card" style={{ padding: 16 }}>
          {window.SCHEDULE.slice(0, 9).map((b, i) => {
            const c = window.CATEGORIES[b.cat];
            return (
              <div key={b.id} style={{
                display: 'grid',
                gridTemplateColumns: '20px 60px 1fr auto auto',
                gap: 12,
                alignItems: 'center',
                padding: '10px 6px',
                borderTop: i ? '1px dashed var(--border)' : 'none',
              }}>
                <window.Icons.Drag size={16} />
                <span className="mono" style={{ fontSize: 11, color: 'var(--text-3)' }}>{window.fmtTime(b.start)}</span>
                <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 3, height: 18, background: c.hex, borderRadius: 2, flex: '0 0 auto' }}></span>
                  <span style={{ fontWeight: 500 }}>{b.title}</span>
                </span>
                <span className="mono" style={{ fontSize: 11, color: 'var(--text-3)' }}>{window.durLabel(b.end - b.start)}</span>
                <window.Icons.Edit size={14} />
              </div>
            );
          })}
        </div>

        <div>
          <div className="card">
            <window.Eyebrow>Summary</window.Eyebrow>
            <div style={{ marginTop: 14 }}>
              <div className="summary-stat"><span>Total planned</span><span className="v">{total}h</span></div>
              <div className="summary-stat"><span>Deep work</span><span className="v">3h 30m</span></div>
              <div className="summary-stat"><span>Movement</span><span className="v">1h 30m</span></div>
              <div className="summary-stat"><span>Rest window</span><span className="v">8h</span></div>
            </div>
          </div>
          <div className="card" style={{ marginTop: 16 }}>
            <window.Eyebrow>By category</window.Eyebrow>
            <div className="cat-bar" style={{ marginTop: 14 }}>
              {cats.map(c => {
                const pct = (c.planned / total) * 100;
                return <div key={c.cat} style={{ width: `${pct}%`, background: window.CATEGORIES[c.cat].hex }}></div>;
              })}
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 12 }}>
              {cats.map(c => <window.Pill key={c.cat} cat={c.cat} />)}
            </div>
          </div>
          <div className="card" style={{ marginTop: 16 }}>
            <window.Eyebrow>Non-negotiables</window.Eyebrow>
            <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
              {['Strength training', 'Read 30m', 'Journal', '8h sleep window'].map(n => (
                <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13 }}>
                  <span style={{ width: 18, height: 18, background: 'color-mix(in srgb, var(--cat-health) 16%, transparent)', color: 'var(--cat-health)', borderRadius: '50%', display: 'grid', placeItems: 'center' }}>
                    <window.Icons.Check size={11} stroke={3} />
                  </span>
                  {n}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 28 }}>
        <button className="btn btn-outline" onClick={onBack}>← Re-generate</button>
        <button className="btn btn-primary btn-large" onClick={onConfirm}>
          Start my day <window.Icons.ArrowRight size={16} />
        </button>
      </div>
    </>
  );
};

const ScreenPlan = ({ onDone }) => {
  const [step, setStep] = React.useState(1);
  const [loading, setLoading] = React.useState(false);
  const [values, setValues] = React.useState({ energy: 4, mood: 'Focused', sleep: 4, intent: '' });
  const set = (k, v) => setValues(s => ({ ...s, [k]: v }));

  const generate = () => {
    setLoading(true);
    setTimeout(() => { setLoading(false); setStep(3); }, 1100);
  };

  return (
    <div className="page-fade plan-wrap">
      <StepIndicator step={step} />
      {step === 1 && <Step1 values={values} set={set} onNext={() => setStep(2)} />}
      {step === 2 && <Step2 values={values} set={set} loading={loading} onBack={() => setStep(1)} onNext={generate} />}
      {step === 3 && <Step3 onBack={() => setStep(2)} onConfirm={onDone} />}
    </div>
  );
};

window.ScreenPlan = ScreenPlan;
