/* Reusable bits */

const Pill = ({ cat, children }) => {
  const c = window.CATEGORIES[cat];
  if (!c) return null;
  return (
    <span className="pill pill-cat" style={{ '--cat': c.hex }}>
      <span className="dot"></span>
      {children || c.name}
    </span>
  );
};

const Eyebrow = ({ children }) => <div className="label-eyebrow">{children}</div>;

const Ring = ({ pct, size = 22, stroke = 3, color = 'var(--accent)' }) => {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <svg className="habit-ring" width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--border)" strokeWidth={stroke} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={stroke}
        strokeDasharray={c} strokeDashoffset={c * (1 - pct/100)} strokeLinecap="round"
        transform={`rotate(-90 ${size/2} ${size/2})`} />
    </svg>
  );
};

window.Pill = Pill;
window.Eyebrow = Eyebrow;
window.Ring = Ring;
