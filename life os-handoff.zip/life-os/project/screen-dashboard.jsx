/* DASHBOARD */

const StatCard = ({ icon: Ic, label, num, trend, dir = 'up' }) => (
  <div className="stat-card">
    <div className="ic"><Ic size={16} /></div>
    <div className="label">{label}</div>
    <div className="num">{num}</div>
    <div className={`trend ${dir === 'down' ? 'down' : ''}`}>{trend}</div>
  </div>
);

const PlannedActualChart = () => {
  const max = Math.max(...window.PLANNED_VS_ACTUAL.map(r => Math.max(r.planned, r.actual)));
  return (
    <div className="bar-chart">
      {window.PLANNED_VS_ACTUAL.map(r => {
        const c = window.CATEGORIES[r.cat];
        const pP = (r.planned / max) * 100;
        const pA = (r.actual / max) * 100;
        return (
          <div key={r.cat} className="bar-row">
            <div className="name" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ width: 8, height: 8, borderRadius: 2, background: c.hex }}></span>
              {c.name}
            </div>
            <div className="bar-stack" style={{ '--cat': c.hex }}>
              <div className="bar-planned" style={{ width: `${pP}%` }}></div>
              <div className="bar-actual" style={{ width: `${pA}%` }}></div>
            </div>
            <div className="v">{r.actual}h / {r.planned}h</div>
          </div>
        );
      })}
      <div style={{ display: 'flex', gap: 14, fontSize: 11, color: 'var(--text-3)', marginTop: 6, paddingLeft: 92 }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <span style={{ width: 16, height: 4, border: '1.5px dashed var(--text-3)', borderRadius: 2 }}></span> Planned
        </span>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <span style={{ width: 16, height: 4, background: 'var(--text-2)', borderRadius: 2 }}></span> Actual
        </span>
      </div>
    </div>
  );
};

const Donut = () => {
  const data = window.PLANNED_VS_ACTUAL;
  const total = data.reduce((s, d) => s + d.actual, 0);
  const size = 160, stroke = 22;
  const r = (size - stroke) / 2;
  const cx = size / 2, cy = size / 2;
  let acc = 0;
  const arcs = data.map(d => {
    const start = acc / total * Math.PI * 2 - Math.PI / 2;
    acc += d.actual;
    const end = acc / total * Math.PI * 2 - Math.PI / 2;
    const large = end - start > Math.PI ? 1 : 0;
    const x1 = cx + r * Math.cos(start), y1 = cy + r * Math.sin(start);
    const x2 = cx + r * Math.cos(end), y2 = cy + r * Math.sin(end);
    return { cat: d.cat, path: `M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2}`, hex: window.CATEGORIES[d.cat].hex, h: d.actual };
  });
  return (
    <div className="donut-wrap">
      <svg className="donut-svg" viewBox={`0 0 ${size} ${size}`}>
        {arcs.map((a, i) => (
          <path key={i} d={a.path} fill="none" stroke={a.hex} strokeWidth={stroke} strokeLinecap="butt" />
        ))}
        <text x={cx} y={cy - 2} textAnchor="middle" fontFamily="DM Serif Display" fontSize="26" fill="var(--text-1)">{Math.round(total)}h</text>
        <text x={cx} y={cy + 16} textAnchor="middle" fontSize="9" fill="var(--text-3)" letterSpacing="2">TRACKED</text>
      </svg>
      <div className="donut-legend">
        {arcs.map(a => (
          <div key={a.cat} className="legend-row" style={{ '--cat': a.hex }}>
            <span className="sw"></span>
            <span className="name">{window.CATEGORIES[a.cat].name}</span>
            <span className="v">{a.h}h</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const LineChart = ({ data, color = 'var(--accent)', area = true, stroke = 2 }) => {
  const w = 600, h = 180;
  const pad = 12;
  const max = 100, min = 0;
  const step = (w - pad * 2) / (data.length - 1);
  const pts = data.map((v, i) => [pad + i * step, h - pad - ((v - min) / (max - min)) * (h - pad * 2)]);
  // smooth path
  const path = pts.map((p, i, a) => {
    if (i === 0) return `M ${p[0]} ${p[1]}`;
    const prev = a[i-1];
    const cx1 = prev[0] + (p[0] - prev[0]) / 2;
    const cy1 = prev[1];
    const cx2 = prev[0] + (p[0] - prev[0]) / 2;
    const cy2 = p[1];
    return `C ${cx1} ${cy1} ${cx2} ${cy2} ${p[0]} ${p[1]}`;
  }).join(' ');
  const areaPath = `${path} L ${pts[pts.length - 1][0]} ${h - pad} L ${pad} ${h - pad} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      {[0,25,50,75,100].map(g => (
        <line key={g} x1={pad} x2={w-pad} y1={h-pad-(g/100)*(h-pad*2)} y2={h-pad-(g/100)*(h-pad*2)}
          stroke="var(--border)" strokeWidth="1" strokeDasharray={g === 0 || g === 100 ? '' : '2 4'} />
      ))}
      {area && <path d={areaPath} fill="color-mix(in srgb, var(--accent) 8%, transparent)" />}
      <path d={path} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" />
      {pts.map((p, i) => (
        <circle key={i} cx={p[0]} cy={p[1]} r="3" fill="var(--bg-2)" stroke={color} strokeWidth="1.5" />
      ))}
    </svg>
  );
};

const DualLine = () => {
  const w = 600, h = 180, pad = 12;
  const data1 = window.MOOD_TREND, data2 = window.ENERGY_TREND;
  const step = (w - pad*2) / (data1.length - 1);
  const norm = v => h - pad - (v / 5) * (h - pad*2);
  const path = (data) => data.map((v, i) => {
    const x = pad + i * step, y = norm(v);
    if (i === 0) return `M ${x} ${y}`;
    const px = pad + (i-1) * step, py = norm(data[i-1]);
    return `C ${px + step/2} ${py} ${x - step/2} ${y} ${x} ${y}`;
  }).join(' ');
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      {[1,2,3,4,5].map(g => (
        <line key={g} x1={pad} x2={w-pad} y1={norm(g)} y2={norm(g)} stroke="var(--border)" strokeWidth="1" strokeDasharray="2 4" />
      ))}
      <path d={path(data1)} fill="none" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
      <path d={path(data2)} fill="none" stroke="#3B82F6" strokeWidth="2" strokeLinecap="round" />
      {data1.map((v, i) => (
        <circle key={'a'+i} cx={pad + i*step} cy={norm(v)} r="2.5" fill="#F97316" />
      ))}
      {data2.map((v, i) => (
        <circle key={'b'+i} cx={pad + i*step} cy={norm(v)} r="2.5" fill="#3B82F6" />
      ))}
    </svg>
  );
};

const Heatmap = () => {
  const cells = window.HEATMAP;
  return (
    <>
      <div className="hm-months">
        <span>May</span><span>Jun</span><span>Jul</span><span>Aug</span><span>Sep</span><span>Oct</span>
        <span>Nov</span><span>Dec</span><span>Jan</span><span>Feb</span><span>Mar</span><span>Apr</span>
      </div>
      <div className="heatmap-wrap">
        <div className="hm-day-labels">
          <span>M</span><span></span><span>W</span><span></span><span>F</span><span></span><span></span>
        </div>
        <div className="hm-grid">
          {cells.map((v, i) => (
            <div key={i} className="hm-cell" style={{ '--lvl': v }} title={`Day ${i+1}: ${Math.round(v*100)}%`}></div>
          ))}
        </div>
      </div>
    </>
  );
};

const ScreenDashboard = () => {
  const [range, setRange] = React.useState('Week');
  const I = window.Icons;
  const totalROI = window.ROI.reduce((s, r) => s + r.hours, 0);
  return (
    <div className="page-fade">
      <div className="dash-head">
        <div>
          <div className="label-eyebrow" style={{ marginBottom: 4 }}>Insights</div>
          <h1>Your Life Dashboard</h1>
        </div>
        <div className="range-pills">
          {['Week', 'Month', 'Year'].map(r => (
            <button key={r} className={`range-pill ${range === r ? 'active' : ''}`} onClick={() => setRange(r)}>{r}</button>
          ))}
        </div>
      </div>

      <div className="stat-grid">
        <StatCard icon={I.Flame} label="Current streak" num="12 days" trend="↑ 3 vs last" />
        <StatCard icon={I.CheckSquare} label="Avg completion" num="78%" trend="↑ 4%" />
        <StatCard icon={I.Hourglass} label="Hours tracked" num="47h" trend="this week" />
        <StatCard icon={I.Trophy} label="Best day" num="Monday" trend="94% complete" />
      </div>

      <div className="dash-row r1">
        <div className="dash-card">
          <h3>Planned vs Actual hours</h3>
          <div className="sub-h">By life area · this week</div>
          <PlannedActualChart />
        </div>
        <div className="dash-card">
          <h3>Life area breakdown</h3>
          <div className="sub-h">Where the hours went</div>
          <Donut />
        </div>
      </div>

      <div className="dash-row r2">
        <div className="dash-card">
          <h3>Completion rate trend</h3>
          <div className="sub-h">Last 13 days</div>
          <div className="line-chart-wrap"><LineChart data={window.COMPLETION_TREND} /></div>
        </div>
        <div className="dash-card">
          <h3>Mood & energy</h3>
          <div className="sub-h">
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, marginRight: 14 }}>
              <span style={{ width: 10, height: 2, background: '#F97316', borderRadius: 2 }}></span>Mood
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
              <span style={{ width: 10, height: 2, background: '#3B82F6', borderRadius: 2 }}></span>Energy
            </span>
          </div>
          <div className="line-chart-wrap"><DualLine /></div>
        </div>
      </div>

      <div className="dash-card" style={{ marginBottom: 16 }}>
        <h3>Activity heatmap</h3>
        <div className="sub-h">Last 52 weeks · color intensity = completion rate</div>
        <Heatmap />
      </div>

      <div className="dash-row r2">
        <div className="dash-card">
          <h3>Time ROI breakdown</h3>
          <div className="sub-h">{totalROI}h tracked this week</div>
          <div className="roi-bar">
            {window.ROI.map(r => (
              <div key={r.kind} className="roi-seg" style={{ width: `${(r.hours/totalROI)*100}%`, background: r.color }}>
                {r.hours}h
              </div>
            ))}
          </div>
          <div className="roi-legend">
            {window.ROI.map(r => (
              <div key={r.kind} className="item"><span className="sw" style={{ background: r.color }}></span>{r.kind}</div>
            ))}
          </div>
        </div>
        <div className="dash-card">
          <h3>Top habits</h3>
          <div className="sub-h">Completion this period</div>
          {window.HABITS.map(h => (
            <div key={h.name} className="habit-row">
              <window.Ring pct={h.pct} size={22} />
              <div className="name">{h.name}</div>
              <div className="pct">{h.pct}%</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

window.ScreenDashboard = ScreenDashboard;
