const Sidebar = ({ active, onNav, theme, onTheme }) => {
  const I = window.Icons;
  const items = [
    { id: 'today', label: 'Today', icon: I.Home },
    { id: 'plan', label: 'Plan', icon: I.CalendarPlus },
    { id: 'review', label: 'Review', icon: I.CheckSquare },
    { id: 'dashboard', label: 'Dashboard', icon: I.Bar },
    { id: 'history', label: 'History', icon: I.Clock },
    { id: 'settings', label: 'Settings', icon: I.Settings },
  ];
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark"></div>
        <div className="brand-name-wrap">
          <div className="brand-name">Life OS</div>
        </div>
        <div className="brand-dot"></div>
      </div>

      <nav className="nav">
        {items.map(it => {
          const Ico = it.icon;
          return (
            <button key={it.id} className={`nav-item ${active === it.id ? 'active' : ''}`} onClick={() => onNav(it.id)}>
              <Ico size={17} />
              <span>{it.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="sidebar-foot">
        <div className="user-row">
          <div className="avatar">SA</div>
          <div style={{ minWidth: 0 }}>
            <div className="user-name">Sasha A.</div>
            <div className="user-sub">Day 87 · Pro</div>
          </div>
        </div>

        <div className="theme-toggle">
          <div className="pill"></div>
          <button className={theme === 'light' ? 'active' : ''} onClick={() => onTheme('light')}>
            <I.Sun size={13} /> Light
          </button>
          <button className={theme === 'dark' ? 'active' : ''} onClick={() => onTheme('dark')}>
            <I.Moon size={13} /> Dark
          </button>
        </div>
      </div>
    </aside>
  );
};

window.Sidebar = Sidebar;
